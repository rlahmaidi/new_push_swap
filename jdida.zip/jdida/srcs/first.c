/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   first.c                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rlahmaid <rlahmaid@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/10/23 16:00:13 by rlahmaid          #+#    #+#             */
/*   Updated: 2021/10/23 16:55:20 by rlahmaid         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../includes/push_swap.h"

void	first(t_stack **a, t_stack **b, int *chunk)
{
	t_stack	*tmp;
	int		chunks;
	int		i;
	int		l;
	t_range	r;

	l = stack_count(*a);
	if (l == 100)
		chunks = 5;
	else if (l == 500)
		chunks = 11;
	tmp = *a;
	i = 0;
	while (i < l)
	{
		r.s = i;
		r.e = i + (l / chunks);
		from_a_to_b(a, b, r, chunk);
		i += (l / chunks);
		(*chunk)++;
	}
}
