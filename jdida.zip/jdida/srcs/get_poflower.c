/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   get_poflower.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rlahmaid <rlahmaid@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/10/23 16:15:29 by rlahmaid          #+#    #+#             */
/*   Updated: 2021/10/23 16:55:20 by rlahmaid         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../includes/push_swap.h"

int	get_poflower(t_stack *a, int chunk)
{
	t_stack	*tmp;
	int		min;
	int		i;
	int		p;

	tmp = a;
	min = tmp->data;
	p = 0;
	i = 0;
	while (tmp)
	{
		if (tmp->data < min && tmp->chunk == chunk)
		{
			min = tmp->data;
			p = i;
		}
		tmp = tmp->next;
		i++;
	}
	return (p);
}
