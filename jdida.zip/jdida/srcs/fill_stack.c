/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   fill_stack.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rlahmaid <rlahmaid@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/10/23 16:00:06 by rlahmaid          #+#    #+#             */
/*   Updated: 2021/10/23 17:02:00 by rlahmaid         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../includes/push_swap.h"

void	fill_stack(t_stack **a)
{
	t_stack	*tmp;
	t_stack	*c;

	c = copy(*a);
	tmp = *a;
	while (tmp)
	{
		tmp->data = get_position(c, tmp->data);
		tmp = tmp->next;
	}
	clear_stack(&c, free);
}
