/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   get_numbers.c                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rlahmaid <rlahmaid@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/10/23 16:04:25 by rlahmaid          #+#    #+#             */
/*   Updated: 2021/10/23 16:55:20 by rlahmaid         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../includes/utils.h"

void	get_numbers(t_stack **a, int ac, char **av)
{
	while (ac > 0)
	{
		if (check_error(ac, av))
		{
			clear_stack(a, free);
			ft_puterror();
		}
		push(a, ft_atoi(av[ac]), 0);
		ac--;
	}
}
