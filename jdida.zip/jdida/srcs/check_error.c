/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   check_error.c                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rlahmaid <rlahmaid@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/10/23 15:59:02 by rlahmaid          #+#    #+#             */
/*   Updated: 2021/10/23 16:55:20 by rlahmaid         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../includes/utils.h"

int	check_error(int ac, char **av)
{
	int	i;

	i = 0;
	while (av[ac][i])
	{
		if (!(av[ac][0] == '+' || av[ac][0] == '-' || ft_isdigit(av[ac][i])))
			return (1);
		i++;
	}
	if (is_dup(ac, av))
		return (1);
	return (0);
}
