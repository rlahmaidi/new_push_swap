/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   copy.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rlahmaid <rlahmaid@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/10/23 15:59:20 by rlahmaid          #+#    #+#             */
/*   Updated: 2021/10/23 17:31:48 by rlahmaid         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../includes/utils.h"

t_stack	*copy(t_stack *a)
{
	t_stack	*tmp;
	t_stack	*new;

	new = NULL;
	tmp = a;
	while (tmp)
	{
		push(&new, tmp->data, tmp->chunk);
		tmp = tmp->next;
	}
	return (new);
}
