/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   is_dup.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rlahmaid <rlahmaid@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/10/23 16:19:51 by rlahmaid          #+#    #+#             */
/*   Updated: 2021/10/23 16:55:20 by rlahmaid         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../includes/utils.h"

int	is_dup(int ac, char **av)
{
	int		i;
	long	t;

	t = ft_atoi(av[ac]);
	if (t < MIN_INT || t > MAX_INT)
		return (1);
	if (!av[ac + 1])
		return (0);
	i = ac + 1;
	while (av[i])
	{
		if (t == ft_atoi(av[i]))
			return (1);
		i++;
	}
	return (0);
}
