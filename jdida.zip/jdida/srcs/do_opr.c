/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   do_opr.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rlahmaid <rlahmaid@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/10/23 15:59:36 by rlahmaid          #+#    #+#             */
/*   Updated: 2021/10/23 16:55:20 by rlahmaid         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../includes/utils.h"

void	do_opr(t_stack **a, t_stack **b, int chunk, char *opr)
{
	if (!ft_strcmp(opr, "sa"))
		swap(a);
	if (!ft_strcmp(opr, "sb"))
		swap(b);
	if (!ft_strcmp(opr, "pa"))
		push_a(a, b, chunk);
	if (!ft_strcmp(opr, "pb"))
		push_b(a, b, chunk);
	if (!ft_strcmp(opr, "ra"))
		rotate(a);
	if (!ft_strcmp(opr, "rb"))
		rotate(b);
	if (!ft_strcmp(opr, "rr"))
		rotate_r(a, b);
	if (!ft_strcmp(opr, "rra"))
		reverse_rotate(a);
	if (!ft_strcmp(opr, "rrb"))
		reverse_rotate(b);
	if (!ft_strcmp(opr, "rrr"))
		reverse_rotate_r(a, b);
}
